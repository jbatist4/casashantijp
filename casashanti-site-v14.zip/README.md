# Casa Shanti — Site Institucional (Estático)

Site institucional da **Casa Shanti** (yoga e bem-estar, João Pessoa - PB),
em **HTML + CSS (Tailwind) + JavaScript puro** — sem WordPress, PHP ou banco de
dados. Pronto para subir via File Manager/FTP em qualquer hospedagem
(Hostinger, etc).

## Estrutura

```
index.html              Home
eventos/index.html       Lista de próximos eventos
evento.html               Detalhe de um evento (?slug=...)
galeria/index.html        Galeria de memórias (eventos realizados)
grade-horarios/index.html Modalidades, grade semanal e planos
locacao/index.html        Locação de espaços
sobre/index.html          Sobre / equipe / como chegar
assets/
  css/style.css           CSS compilado (Tailwind)
  src/input.css           Fonte do Tailwind (não sobe para produção)
  js/                      main.js (menu mobile), gallery-lightbox-v2.js, eventos.js
  images/                  Fotos do site
  data/eventos.json        Dados dos eventos (próximos e realizados)
```

## Atualizando o conteúdo

- **Eventos / Galeria**: edite `assets/data/eventos.json`. Veja o guia completo em
  [`docs/como-adicionar-eventos.md`](docs/como-adicionar-eventos.md).
- **Grade de horários, planos, equipe, locação**: são textos fixos nos arquivos
  HTML correspondentes — edite diretamente o `.html` da página.

## Desenvolvimento local (CSS)

O CSS já vem compilado em `assets/css/style.css`. Só é necessário recompilar se
você adicionar/alterar classes Tailwind no HTML:

```bash
npm install
npm run build   # gera assets/css/style.css uma vez
npm run watch   # recompila automaticamente enquanto edita
```

Para visualizar o site localmente, sirva a pasta raiz com qualquer servidor
estático (necessário para o `fetch()` de `eventos.json` funcionar), por exemplo:

```bash
npx serve .
# ou
python -m http.server 8080
```

## Publicando (deploy)

Veja o checklist em [`docs/deploy-hostinger.md`](docs/deploy-hostinger.md).
